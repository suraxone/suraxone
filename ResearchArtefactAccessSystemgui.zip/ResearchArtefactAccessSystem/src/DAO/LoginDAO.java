package DAO;

import java.sql.*;
import java.util.*;
import Model.Login;

public class LoginDAO {

	private List<Login> fetchAllEmployeeLoginCredentials() throws Exception {
		List<Login> loginList = new ArrayList<Login>();

		Connection con = DBConnection.getConnection();
		Statement st = con.createStatement();
		ResultSet result = st.executeQuery("select * from login");
		while (result.next()) {
			loginList
					.add(new Login(result.getString(1), result.getString(2), result.getString(3), result.getString(4)));
		}
		return loginList;
	}

	public boolean checkEmployeeCredentials(String username, String password) throws Exception {

		Login login = new Login();
		boolean flag = false;
		List<Login> loginList = fetchAllEmployeeLoginCredentials();
		for (int i = 0; i < loginList.size(); i++) {
			if (loginList.get(i).getUsername().equals(username) && loginList.get(i).getPassword().equals(password)) {
				login = loginList.get(i);
				flag = true;
			}
		}
		if (flag) {
			if (login.getUsername().equals(username))
				return true;
			else
				return false;
		} else
			return false;
	}

	public String findRole(String username) throws Exception {
		Login login = new Login();
		List<Login> loginList = fetchAllEmployeeLoginCredentials();
		for (int i = 0; i < loginList.size(); i++) {
			if (loginList.get(i).getUsername().equals(username))
				login = loginList.get(i);
		}
		return login.getDesignation();
	}
}
