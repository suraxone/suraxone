package DAO;

import java.sql.*;

public class DBConnection {
	public static Connection getConnection() throws Exception {

		Connection con;
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "RAAS_project", "suraj");
		return con;
	}
}