package DAO;

import java.sql.*;
import java.util.*;
import Model.*;

public class EmployeesDAO {

	private List<Employees> fetchAllEmployees() throws Exception {
		List<Employees> employeeList = new ArrayList<Employees>();

		Connection con = DBConnection.getConnection();
		Statement st = con.createStatement();
		ResultSet result = st.executeQuery("select * from employees");
		while (result.next()) {
			employeeList.add(new Employees(result.getString(1), result.getInt(2), result.getString(3),
					result.getLong(4), result.getString(5)));
		}
		return employeeList;
	}

	public List<Employees> fetchEmployeeDetails(List<Researchers> researchersList) throws Exception {
		List<Employees> employeeList = fetchAllEmployees();
		List<Employees> employeeDetails = new ArrayList<Employees>();

		for (int i = 0; i < researchersList.size(); i++) {
			for (int j = 0; j < employeeList.size(); j++)
				if (employeeList.get(j).getName().equals(researchersList.get(i).getResearcherName()))
					employeeDetails.add(employeeList.get(j));
		}
		return employeeDetails;
	}

	public List<Employees> fetchAllTeamLeads() throws Exception {
		List<Employees> employeeList = fetchAllEmployees();
		List<Employees> TeamLeadList = new ArrayList<Employees>();
		
		for (int i = 0; i < employeeList.size(); i++) {
			if (employeeList.get(i).getDesignation().equalsIgnoreCase("Team Lead"))
				TeamLeadList.add(employeeList.get(i));
		}
		return TeamLeadList;
	}

}
