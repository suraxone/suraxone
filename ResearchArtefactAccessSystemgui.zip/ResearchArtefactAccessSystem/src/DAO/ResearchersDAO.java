package DAO;

import java.sql.*;
import java.util.*;
import Model.*;
import main.Main;

public class ResearchersDAO {

	private List<Researchers> fetchAllResearchers() throws Exception {
		List<Researchers> researchersList = new ArrayList<Researchers>();

		Connection con = DBConnection.getConnection();
		Statement st = con.createStatement();
		ResultSet result = st.executeQuery("select * from researchers");
		while (result.next()) {
			researchersList.add(new Researchers(result.getString(1), result.getString(2), result.getString(3),
					result.getBoolean(4)));
		}
		return researchersList;
	}



	public List<Researchers> fetchAllResearchersWithSameManager(String managerName) throws Exception {

		List<Researchers> researchersList = fetchAllResearchers();
		List<Researchers> managerList = new ArrayList<Researchers>();
		for (int i = 0; i < researchersList.size(); i++) {
			if (researchersList.get(i).getManager().equals(managerName))
				managerList.add(researchersList.get(i));
		}

		return managerList;

	}

	public List<Researchers> fetchAllResearchersWithSameTeamLead(String teamLead, List<Employees> employeeList)
			throws Exception {

		List<Researchers> researchersList = fetchAllResearchers();
		for (int i = 0; i < researchersList.size(); i++) {
			for (int j = 0; j < employeeList.size(); j++)
				if (employeeList.get(j).getName().equals(researchersList.get(i).getResearcherName()))
					researchersList.remove(i);
		}
		List<Researchers> teamLeadList = new ArrayList<Researchers>();
		for (int i = 0; i < researchersList.size(); i++) {
			if (researchersList.get(i).getTeamlead().equals(teamLead))
				teamLeadList.add(researchersList.get(i));
		}

		return teamLeadList;

	}

	public Researchers fetchResearcher(String name) throws Exception {

		List<Researchers> researchersList = fetchAllResearchers();

		Researchers researcher = new Researchers();

		for (int i = 0; i < researchersList.size(); i++) {
			if (researchersList.get(i).getResearcherName().equalsIgnoreCase(name))
				researcher = researchersList.get(i);
		}

		return researcher;
	}

	public boolean searchResearcher(String name) throws Exception {

		try {
			Researchers researcher = fetchResearcher(name);
			if (researcher.getResearcherName().equalsIgnoreCase(name))
				return true;
			else
				return false;
		} catch (Exception e) {
			return false;
		}

	}
}
