package DAO;

import java.sql.*;
import java.time.LocalDate;
import java.util.*;
import Model.*;
import main.Main;

public class ArtifactsDAO {
	
	private List<Artifacts> fetchAllArtifacts() throws Exception {
		List<Artifacts> artifactsList = new ArrayList<Artifacts>();

		Connection con = DBConnection.getConnection();
		Statement st = con.createStatement();
		ResultSet result = st.executeQuery("select * from artifacts");
		while (result.next()) {
			artifactsList.add(new Artifacts(result.getLong(1), result.getString(2), result.getInt(3),
					result.getString(4), result.getString(5)));
		}
		return artifactsList;
	}

	public List<Artifacts> fetchAllArtifactsWithResearcherName(String name) throws Exception {
		List<Artifacts> artifactsList = fetchAllArtifacts();
		List<Artifacts> artifactsOfResearcher = new ArrayList<Artifacts>();

		for (int i = 0; i < artifactsList.size(); i++)
			if (artifactsList.get(i).getResearcherName().equals(name))
				artifactsOfResearcher.add(artifactsList.get(i));

		return artifactsOfResearcher;
	}

	public List<Artifacts> fetchArtifactsDetails(List<Researchers> researchersList) throws Exception {
		List<Artifacts> artifactsList = fetchAllArtifacts();
		List<Artifacts> artifactsDetails = new ArrayList<Artifacts>();

		for (int i = 0; i < researchersList.size(); i++) {
			for (int j = 0; j < artifactsList.size(); j++)
				if (artifactsList.get(j).getResearcherName().equals(researchersList.get(i).getResearcherName()))
					artifactsDetails.add(artifactsList.get(j));
		}

		return artifactsDetails;

	}
	
	public void uploadFile(String path, String topic) throws Exception {
		LocalDate currentdate = LocalDate.now();
		Connection con = DBConnection.getConnection();
		Statement st = con.createStatement();
		st.executeUpdate("insert into artifacts(topic,Published_Year,Researcher_name,Disk_location) Values('" + topic + "'," + currentdate.getYear() + ",'" + Main.username + "','" + path + "')");
	}

}
