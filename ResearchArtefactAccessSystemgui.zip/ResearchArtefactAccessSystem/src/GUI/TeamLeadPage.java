package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import Model.Employees;
import main.Main;
import views.TeamLeadView;

public class TeamLeadPage {

	public static JFrame frame;
	public static JLabel errorLabel = new JLabel("");
	public static List<Employees> employeesList = new ArrayList<Employees>();
	public static DefaultTableModel model;

	public TeamLeadPage() {

		TeamLeadView view = new TeamLeadView();

		frame = new JFrame();
		frame.setTitle("TEAM LEAD VIEW");
		frame.setBounds(100, 100, 1072, 764);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel welcomeLabel = new JLabel("WELCOME " + Main.username);
		welcomeLabel.setFont(new Font("Sitka Text", Font.BOLD, 18));
		welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
		welcomeLabel.setBounds(238, 77, 444, 40);
		frame.getContentPane().add(welcomeLabel);

		JButton logoutButton = new JButton("LOGOUT");
		logoutButton.setFont(new Font("Britannic Bold", Font.BOLD | Font.ITALIC, 18));
		logoutButton.setBounds(0, 0, 109, 34);
		logoutButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				try {
					Main.main(null);
				} catch (Exception e1) {
					e1.printStackTrace();
				}

			}
		});
		frame.getContentPane().add(logoutButton);

		JLabel selectOptionLabel = new JLabel("PLEASE SELECT AN OPTION :");
		selectOptionLabel.setFont(new Font("Verdana", Font.BOLD, 16));
		selectOptionLabel.setBounds(331, 181, 292, 40);
		frame.getContentPane().add(selectOptionLabel);

		JCheckBox chckbxViewAllResearchers = new JCheckBox("View all researchers under you");
		chckbxViewAllResearchers.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxViewAllResearchers.setFont(new Font("Microsoft New Tai Lue", Font.BOLD | Font.ITALIC, 15));
		chckbxViewAllResearchers.setBounds(331, 245, 252, 47);
		chckbxViewAllResearchers.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				try {
					view.viewAllResearchers();

					JTable table = new JTable(model) {
						public boolean isCellEditable(int rowIndex, int colIndex) {
							return false; // Disallow the editing of any cell
						}
					};
					table.setBounds(43, 461, 979, 164);
					table.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent me) {
							if (me.getClickCount() == 2) { // to detect double click events
								JTable target = (JTable) me.getSource();
								int row = target.getSelectedRow(); // select a row
								try {
									view.selection(employeesList, row);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						}
					});
					JTableHeader header = table.getTableHeader();
					header.setBackground(Color.yellow);
					JScrollPane scrollPane = new JScrollPane(table);
					scrollPane.setBounds(43, 461, 979, 164);
					table.setFillsViewportHeight(true);
					frame.getContentPane().add(scrollPane);
				} catch (Exception e1) {
					e1.printStackTrace();
				}

			}
		});
		frame.getContentPane().add(chckbxViewAllResearchers);

		JCheckBox chckbxViewAllArtifacs = new JCheckBox("View all research work items of your team");
		chckbxViewAllArtifacs.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxViewAllArtifacs.setFont(new Font("Microsoft New Tai Lue", Font.BOLD | Font.ITALIC, 15));
		chckbxViewAllArtifacs.setBounds(331, 380, 252, 47);
		chckbxViewAllArtifacs.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent e) {
				try {
					view.viewAllArtifacts();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		frame.getContentPane().add(chckbxViewAllArtifacs);

		JCheckBox chckbxResearcherPage = new JCheckBox("Go to researcher home page");
		chckbxResearcherPage.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxResearcherPage.setFont(new Font("Microsoft New Tai Lue", Font.BOLD | Font.ITALIC, 15));
		chckbxResearcherPage.setBounds(331, 314, 252, 47);
		chckbxResearcherPage.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				ResearcherPage page = new ResearcherPage();
				page.frame.setVisible(true);
			}
		});
		frame.getContentPane().add(chckbxResearcherPage);

		errorLabel.setForeground(Color.RED);
		errorLabel.setFont(new Font("Segoe UI Black", Font.BOLD | Font.ITALIC, 18));
		errorLabel.setHorizontalAlignment(SwingConstants.CENTER);
		errorLabel.setBounds(181, 424, 584, 47);
		frame.getContentPane().add(errorLabel);

//		JButton btnHome = new JButton("HOME");
//		btnHome.setFont(new Font("Britannic Bold", Font.BOLD | Font.ITALIC, 18));
//		btnHome.setBounds(949, 0, 109, 34);
//		frmManagerView.getContentPane().add(btnHome);

	}

}
