package GUI;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import javax.swing.table.*;

import main.Main;
import views.ManagerView;

public class SearchResearcherPage {

	public JFrame frmSearchResearcher;
	public static DefaultTableModel model;
	public static JLabel errorLabel = new JLabel("");
	private ManagerView view = new ManagerView();

	public SearchResearcherPage() {
		frmSearchResearcher = new JFrame();
		frmSearchResearcher.setTitle("SEARCH RESEARCHER");
		frmSearchResearcher.setBounds(100, 100, 1057, 682);
		frmSearchResearcher.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmSearchResearcher.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("SEARCH FOR A RESEARCHER");
		lblNewLabel.setFont(new Font("Segoe UI Historic", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(401, 57, 287, 37);
		frmSearchResearcher.getContentPane().add(lblNewLabel);

		JTextField txtResearcherName = new JTextField();
		txtResearcherName.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 17));
		txtResearcherName.setBounds(415, 160, 273, 37);
		frmSearchResearcher.getContentPane().add(txtResearcherName);
		txtResearcherName.setColumns(20);

		JButton searchButton = new JButton("SEARCH");
		searchButton.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 18));
		searchButton.setBounds(728, 166, 120, 31);
		searchButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					view.searchResearcher(txtResearcherName.getText());
					JTable table = new JTable(model) {
						public boolean isCellEditable(int rowIndex, int colIndex) {
							return false; // Disallow the editing of any cell
						}
					};

					table.setBounds(150, 320, 836, 264);
					JTableHeader header = table.getTableHeader();
					header.setBackground(Color.yellow);
					JScrollPane scrollPane = new JScrollPane(table);
//					scrollPane.setSize(600, 600);
					scrollPane.setBounds(150, 320, 836, 264);
					table.setFillsViewportHeight(true);
					frmSearchResearcher.getContentPane().add(scrollPane);
					txtResearcherName.setText("");
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		frmSearchResearcher.getContentPane().add(searchButton);

//		errorLabel = new JLabel("error");
		errorLabel.setForeground(Color.RED);
		errorLabel.setHorizontalAlignment(SwingConstants.CENTER);
		errorLabel.setFont(new Font("Trebuchet MS", Font.BOLD, 17));
		errorLabel.setBounds(416, 241, 301, 37);
		frmSearchResearcher.getContentPane().add(errorLabel);

		JButton logoutButton = new JButton("LOGOUT");
		logoutButton.setFont(new Font("Britannic Bold", Font.BOLD | Font.ITALIC, 18));
		logoutButton.setBounds(0, 0, 109, 34);
		logoutButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frmSearchResearcher.dispose();
				try {
					Main.main(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		frmSearchResearcher.getContentPane().add(logoutButton);
		
		JButton homeButton = new JButton("HOME");
		homeButton.setFont(new Font("Britannic Bold", Font.BOLD | Font.ITALIC, 18));
		homeButton.setBounds(949, 0, 109, 34);
		homeButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frmSearchResearcher.dispose();
				ManagerPage.frmManagerView.setVisible(true);
			}
		});
		frmSearchResearcher.getContentPane().add(homeButton);
	}

}
