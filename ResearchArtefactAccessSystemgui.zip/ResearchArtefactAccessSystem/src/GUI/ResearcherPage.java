package GUI;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import Model.Employees;
import main.Main;
import views.ResearcherView;

public class ResearcherPage {

	public static JFrame frame;
	public static JLabel errorLabel = new JLabel("");
	public static List<Employees> employeesList = new ArrayList<Employees>();
	public static DefaultTableModel model;

	public ResearcherPage() {

		ResearcherView view = new ResearcherView();
		
		frame = new JFrame();
		frame.setBounds(100, 100, 1068, 691);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel welcomeLabel = new JLabel("WELCOME " + Main.username);
		welcomeLabel.setFont(new Font("Sitka Text", Font.BOLD, 18));
		welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
		welcomeLabel.setBounds(290, 77, 444, 40);
		frame.getContentPane().add(welcomeLabel);

		JButton logoutButton = new JButton("LOGOUT");
		logoutButton.setFont(new Font("Britannic Bold", Font.BOLD | Font.ITALIC, 18));
		logoutButton.setBounds(0, 0, 109, 34);
		logoutButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				try {
					Main.main(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		frame.getContentPane().add(logoutButton);

		JLabel selectOptionLabel = new JLabel("PLEASE SELECT AN OPTION :");
		selectOptionLabel.setFont(new Font("Verdana", Font.BOLD, 16));
		selectOptionLabel.setBounds(400, 178, 292, 40);
		frame.getContentPane().add(selectOptionLabel);

		JCheckBox chckbxViewArtifacts = new JCheckBox("View your published research work items");
		chckbxViewArtifacts.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxViewArtifacts.setFont(new Font("Microsoft New Tai Lue", Font.BOLD | Font.ITALIC, 15));
		chckbxViewArtifacts.setBounds(361, 251, 338, 47);
		chckbxViewArtifacts.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				try {
					view.viewAllResearchArtifacts();
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				
			}
		});
		frame.getContentPane().add(chckbxViewArtifacts);

		JCheckBox chckbxUploadResearchArtifact = new JCheckBox("Upload new research work artifacts");
		chckbxUploadResearchArtifact.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxUploadResearchArtifact.setFont(new Font("Microsoft New Tai Lue", Font.BOLD | Font.ITALIC, 15));
		chckbxUploadResearchArtifact.setBounds(361, 341, 338, 47);
		chckbxUploadResearchArtifact.addItemListener(new ItemListener() {
			
			@Override
			public void itemStateChanged(ItemEvent e) {
				UploadArtifactPage page = new UploadArtifactPage();
				page.frmUploadFile.setVisible(true);
			}
		});
		frame.getContentPane().add(chckbxUploadResearchArtifact);

		errorLabel.setForeground(Color.RED);
		errorLabel.setFont(new Font("Segoe UI Black", Font.BOLD | Font.ITALIC, 18));
		errorLabel.setHorizontalAlignment(SwingConstants.CENTER);
		errorLabel.setBounds(256, 436, 584, 47);
		frame.getContentPane().add(errorLabel);

	}

}
