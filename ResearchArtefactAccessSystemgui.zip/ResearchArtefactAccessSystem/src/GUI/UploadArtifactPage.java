package GUI;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.*;

import views.ResearcherView;

public class UploadArtifactPage {

	public static JFrame frmUploadFile;
	JLabel errorLabel = new JLabel("");
	JFileChooser fc;

	public UploadArtifactPage() {

		ResearcherView view = new ResearcherView();

		frmUploadFile = new JFrame();
		frmUploadFile.setTitle("UPLOAD FILE");
		frmUploadFile.setBounds(100, 100, 1083, 684);
		frmUploadFile.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmUploadFile.getContentPane().setLayout(null);

		fc = new JFileChooser();

		JLabel headingLabel = new JLabel("UPLOAD NEW RESEARCH ARTIFACT");
		headingLabel.setForeground(new Color(0, 0, 0));
		headingLabel.setHorizontalAlignment(SwingConstants.CENTER);
		headingLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
		headingLabel.setBounds(387, 90, 397, 52);
		frmUploadFile.getContentPane().add(headingLabel);

		JLabel topicLabel = new JLabel("TOPIC");
		topicLabel.setFont(new Font("Segoe UI Historic", Font.BOLD, 18));
		topicLabel.setHorizontalAlignment(SwingConstants.CENTER);
		topicLabel.setBounds(387, 211, 99, 42);
		frmUploadFile.getContentPane().add(topicLabel);

		JTextField topicTextField = new JTextField();
		topicTextField.setHorizontalAlignment(SwingConstants.CENTER);
		topicTextField.setFont(new Font("Times New Roman", Font.BOLD, 17));
		topicTextField.setBounds(542, 211, 163, 42);
		topicTextField.setColumns(10);
		frmUploadFile.getContentPane().add(topicTextField);

		JLabel fileLabel = new JLabel("FILE");
		fileLabel.setHorizontalAlignment(SwingConstants.CENTER);
		fileLabel.setFont(new Font("Segoe UI Historic", Font.BOLD, 18));
		fileLabel.setBounds(387, 355, 99, 42);
		frmUploadFile.getContentPane().add(fileLabel);

		JTextField filePathTextField = new JTextField();
		filePathTextField.setHorizontalAlignment(SwingConstants.CENTER);
		filePathTextField.setFont(new Font("Times New Roman", Font.BOLD, 15));
		filePathTextField.setColumns(10);
		filePathTextField.setBounds(542, 355, 163, 42);
		frmUploadFile.getContentPane().add(filePathTextField);

		JButton browseButton = new JButton("BROWSE");
		browseButton.setFont(new Font("DialogInput", Font.BOLD, 22));
		browseButton.setForeground(Color.BLACK);
		browseButton.setBounds(798, 359, 121, 42);
		browseButton.addActionListener(null);
		browseButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int x = fc.showOpenDialog(null);
				if (x == JFileChooser.APPROVE_OPTION) {
					File f1 = fc.getSelectedFile();
					filePathTextField.setText(f1.getAbsolutePath());
				}

			}
		});
		frmUploadFile.getContentPane().add(browseButton);

		JButton submitButton = new JButton("SUBMIT");
		submitButton.setForeground(Color.BLACK);
		submitButton.setFont(new Font("DialogInput", Font.BOLD, 22));
		submitButton.setBounds(637, 483, 121, 42);
		submitButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (!topicTextField.getText().isEmpty()) {
					if (!filePathTextField.getText().isEmpty()) {
						try {
							view.uploadFile(filePathTextField.getText(), topicTextField.getText());
							JOptionPane.showMessageDialog(null, "FIle uploaded successfully !");
							frmUploadFile.dispose();
							ResearcherPage page = new ResearcherPage();
							page.frame.setVisible(true);
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					} else {
						errorLabel.setText("Please provide file path");
					}
				}
				else
					errorLabel.setText("Please enter a topic for research work item");

			}
		});
		frmUploadFile.getContentPane().add(submitButton);

		errorLabel.setHorizontalAlignment(SwingConstants.CENTER);
		errorLabel.setForeground(Color.RED);
		errorLabel.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		errorLabel.setBounds(397, 153, 387, 32);
		frmUploadFile.getContentPane().add(errorLabel);

	}

}
