package GUI;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.List;

import javax.swing.*;
import javax.swing.table.*;
import Model.Artifacts;
import main.Authentication;
import main.Main;
import views.ManagerView;
import views.ResearcherView;
import views.TeamLeadView;
import views.View;

public class ViewArtifactsPage {

	public JFrame frame;
	public static DefaultTableModel model;
	public static List<Artifacts> artifactsList;
	private int num;
	private View view = null;
	JLabel errorLabel = new JLabel("");

	public ViewArtifactsPage() {

		try {
			if (Authentication.checkRole().equalsIgnoreCase("Manager"))
				view = new ManagerView();
			else if (Authentication.checkRole().equalsIgnoreCase("Team Lead"))
				view = new TeamLeadView();
			else
				view = new ResearcherView();

		} catch (Exception e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		frame = new JFrame();
		frame.setTitle("VIEW ARTIFACTS");
		frame.setBounds(100, 100, 1064, 679);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JButton viewFileButton = new JButton("VIEW FILE");
		viewFileButton.setBackground(Color.ORANGE);
		viewFileButton.setFont(new Font("Sitka Text", Font.BOLD | Font.ITALIC, 17));
		viewFileButton.setBounds(816, 477, 145, 51);
		viewFileButton.setEnabled(false);
		viewFileButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String path = view.getArtifactsPath(artifactsList, num);
				File f = new File(path);
				Desktop d = Desktop.getDesktop();
				try {
					d.open(f);
				} catch (IllegalArgumentException | IOException e1) {
					errorLabel.setText("File Moved or deleted from given location");
				}

			}
		});
		frame.getContentPane().add(viewFileButton);

		JTable table = new JTable(model) {
			public boolean isCellEditable(int rowIndex, int colIndex) {
				return false; // Disallow the editing of any cell
			}
		};

		table.setBounds(91, 54, 864, 358);
		table.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent me) {
				if (me.getClickCount() == 2) { // to detect double click events
					JTable target = (JTable) me.getSource();
					num = target.getSelectedRow(); // select a row
					viewFileButton.setEnabled(true);
				}
			}
		});

		JTableHeader header = table.getTableHeader();
		header.setBackground(Color.yellow);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(91, 54, 864, 358);
		table.setFillsViewportHeight(true);
		frame.getContentPane().add(scrollPane);

		JButton logoutButton = new JButton("LOGOUT");
		logoutButton.setFont(new Font("Britannic Bold", Font.BOLD | Font.ITALIC, 18));
		logoutButton.setBounds(0, 0, 109, 34);
		logoutButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				try {
					Main.main(null);
				} catch (Exception e1) {
					e1.printStackTrace();
				}

			}
		});
		frame.getContentPane().add(logoutButton);

		JButton homeButton = new JButton("HOME");
		homeButton.setFont(new Font("Britannic Bold", Font.BOLD | Font.ITALIC, 18));
		homeButton.setBounds(949, 0, 109, 34);
		homeButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				try {
					Authentication.Login();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		frame.getContentPane().add(homeButton);
		
		
		errorLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
		errorLabel.setForeground(Color.RED);
		errorLabel.setHorizontalAlignment(SwingConstants.CENTER);
		errorLabel.setBounds(128, 423, 803, 37);
		frame.getContentPane().add(errorLabel);
	}
}
