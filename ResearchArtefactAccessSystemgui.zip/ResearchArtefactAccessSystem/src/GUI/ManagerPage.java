package GUI;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

import javax.swing.*;
import javax.swing.table.*;
import Model.Employees;
import main.Main;
import views.ManagerView;

public class ManagerPage extends JFrame {

	public static JFrame frmManagerView;
	public static JLabel errorLabel = new JLabel("");
	public static List<Employees> employeesList = new ArrayList<Employees>();
	public static DefaultTableModel model;

	public ManagerPage() {

		ManagerView view = new ManagerView();
		
		frmManagerView = new JFrame();
		frmManagerView.setTitle("MANAGER VIEW");
		frmManagerView.setBounds(100, 100, 1072, 764);
		frmManagerView.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmManagerView.getContentPane().setLayout(null);

		JLabel welcomeLabel = new JLabel("WELCOME "+Main.username);
		welcomeLabel.setFont(new Font("Sitka Text", Font.BOLD, 18));
		welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
		welcomeLabel.setBounds(238, 77, 444, 40);
		frmManagerView.getContentPane().add(welcomeLabel);

		JButton logoutButton = new JButton("LOGOUT");
		logoutButton.setFont(new Font("Britannic Bold", Font.BOLD | Font.ITALIC, 18));
		logoutButton.setBounds(0, 0, 109, 34);
		logoutButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				frmManagerView.dispose();
				try {
					Main.main(null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		frmManagerView.getContentPane().add(logoutButton);

		JLabel selectOptionLabel = new JLabel("PLEASE SELECT AN OPTION :");
		selectOptionLabel.setFont(new Font("Verdana", Font.BOLD, 16));
		selectOptionLabel.setBounds(331, 181, 292, 40);
		frmManagerView.getContentPane().add(selectOptionLabel);

		JCheckBox chckbxViewAllResearchers = new JCheckBox("View all researchers under you");
		chckbxViewAllResearchers.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxViewAllResearchers.setFont(new Font("Microsoft New Tai Lue", Font.BOLD | Font.ITALIC, 15));
		chckbxViewAllResearchers.setBounds(331, 267, 252, 47);
		chckbxViewAllResearchers.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				try {
					view.viewAllResearchers();
					if(model.getRowCount()>0) {
					JTable table = new JTable(model) {
						public boolean isCellEditable(int rowIndex, int colIndex) {
							return false; // Disallow the editing of any cell
						}
					};
					table.setBounds(69, 462, 896, 213);
					table.addMouseListener(new MouseAdapter() {
						public void mouseClicked(MouseEvent me) {
							if (me.getClickCount() == 2) { // to detect double click events
								JTable target = (JTable) me.getSource();
								int row = target.getSelectedRow(); // select a row
								try {
									view.selection(employeesList,row);
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						}
					});
					JTableHeader header = table.getTableHeader();
					header.setBackground(Color.yellow);
					JScrollPane scrollPane = new JScrollPane(table);
//					scrollPane.setSize(600, 600);
					scrollPane.setBounds(69, 462, 896, 155);
					table.setFillsViewportHeight(true);
					frmManagerView.getContentPane().add(scrollPane);
				}
//					frmManagerView.getContentPane().add(scrollPane);
				} catch (Exception e1) {
					e1.printStackTrace();
				}

			}
		});
		frmManagerView.getContentPane().add(chckbxViewAllResearchers);

		JCheckBox chckbxSearchForResearcher = new JCheckBox("Search for researcher");
		chckbxSearchForResearcher.setHorizontalAlignment(SwingConstants.CENTER);
		chckbxSearchForResearcher.setFont(new Font("Microsoft New Tai Lue", Font.BOLD | Font.ITALIC, 15));
		chckbxSearchForResearcher.setBounds(319, 360, 252, 47);
		chckbxSearchForResearcher.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				frmManagerView.dispose();
				chckbxViewAllResearchers.setSelected(false);
				SearchResearcherPage searchResearcherPage = new SearchResearcherPage();
				searchResearcherPage.frmSearchResearcher.setVisible(true);
			}
		});
		frmManagerView.getContentPane().add(chckbxSearchForResearcher);

		errorLabel.setForeground(Color.RED);
		errorLabel.setFont(new Font("Segoe UI Black", Font.BOLD | Font.ITALIC, 18));
		errorLabel.setHorizontalAlignment(SwingConstants.CENTER);
		errorLabel.setBounds(182, 514, 584, 47);
		frmManagerView.getContentPane().add(errorLabel);

	}
}
