package GUI;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import main.*;

public class LoginPage extends JFrame {

	public JFrame frmLogin;
	public static JLabel error = new JLabel("");

	public LoginPage() {

		frmLogin = new JFrame();
		frmLogin.setTitle("LOGIN");
		frmLogin.setBounds(100, 100, 1054, 712);
		frmLogin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLogin.getContentPane().setLayout(null);

		JLabel headingLabel = new JLabel("WELCOME TO RESEARCH ARTIFACT ACCESS SYSTEM");
		headingLabel.setBackground(SystemColor.controlLtHighlight);
		headingLabel.setFont(new Font("Rockwell", Font.BOLD, 24));
		headingLabel.setHorizontalAlignment(SwingConstants.CENTER);
		headingLabel.setBounds(130, 80, 717, 76);
		frmLogin.getContentPane().add(headingLabel);

		JLabel loginLabel = new JLabel("LOGIN");
		loginLabel.setFont(new Font("Segoe UI Black", Font.BOLD, 25));
		loginLabel.setBackground(Color.WHITE);
		loginLabel.setHorizontalAlignment(SwingConstants.CENTER);
		loginLabel.setBounds(454, 167, 106, 63);
		frmLogin.getContentPane().add(loginLabel);

		JLabel usernameLabel = new JLabel("Username");
		usernameLabel.setHorizontalAlignment(SwingConstants.CENTER);
		usernameLabel.setFont(new Font("Segoe UI Black", Font.BOLD | Font.ITALIC, 16));
		usernameLabel.setBounds(226, 303, 113, 32);
		frmLogin.getContentPane().add(usernameLabel);

		JLabel passwordLabel = new JLabel("Password");
		passwordLabel.setHorizontalAlignment(SwingConstants.CENTER);
		passwordLabel.setFont(new Font("Segoe UI Black", Font.BOLD | Font.ITALIC, 16));
		passwordLabel.setBounds(226, 377, 113, 32);
		frmLogin.getContentPane().add(passwordLabel);

		JTextField usernameTextField = new JTextField();
		usernameTextField.setBounds(370, 312, 113, 23);
		frmLogin.getContentPane().add(usernameTextField);
		usernameTextField.setColumns(10);

		JTextField passwordTextField = new JPasswordField();
		passwordTextField.setColumns(10);
		passwordTextField.setBounds(370, 386, 113, 23);
		frmLogin.getContentPane().add(passwordTextField);

		error.setFont(new Font("Georgia", Font.BOLD, 16));
		error.setForeground(Color.RED);
		error.setHorizontalAlignment(SwingConstants.CENTER);
		error.setBounds(277, 264, 451, 32);
		frmLogin.getContentPane().add(error);

		JButton cancelButton = new JButton("CANCEL");
		cancelButton.setFont(new Font("Segoe UI Historic", Font.BOLD, 18));
		cancelButton.setBounds(138, 515, 138, 23);
		cancelButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				frmLogin.dispose();
			}
		});
		frmLogin.getContentPane().add(cancelButton);

		JButton submitButton = new JButton("SUBMIT");
		submitButton.setFont(new Font("Segoe UI Historic", Font.BOLD, 18));
		submitButton.setBounds(614, 509, 138, 23);
		submitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Main.username = usernameTextField.getText();
				String passValue = passwordTextField.getText();

				try {
					if (Authentication.CheckUserCredentials(passValue)) {
						frmLogin.dispose();
						Authentication.Login();
					} else {
						error.setText("Incorrect username / password. Please try again");
						usernameTextField.setText("");
						passwordTextField.setText("");
					}
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		frmLogin.getContentPane().add(submitButton);
	}
}