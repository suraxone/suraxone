package main;

import DAO.*;
import GUI.LoginPage;
import GUI.ManagerPage;
import GUI.ResearcherPage;
import GUI.TeamLeadPage;
import views.*;

public class Authentication {

	private static LoginDAO loginDAO = new LoginDAO();

	public static boolean CheckUserCredentials(String password) throws Exception {
		return loginDAO.checkEmployeeCredentials(Main.username, password);
	}

	public static void Login() throws Exception {
		ResearchersDAO researcherDAO = new ResearchersDAO();
		switch (loginDAO.findRole(Main.username)) {
		case "Manager": {
			ManagerPage page = new ManagerPage();
			page.frmManagerView.setVisible(true);
			break;
		}
		case "Team Lead": {
			if (!researcherDAO.fetchResearcher(Main.username).isAdvisorApproved())
				LoginPage.error.setText("You do not have access to this page, please contact your superiors.");
			else {
				TeamLeadPage page = new TeamLeadPage();
				page.frame.setVisible(true);
				break;
			}
		}
		case "Researcher": {
			if (!researcherDAO.fetchResearcher(Main.username).isAdvisorApproved())
				LoginPage.error.setText("You do not have access to this page, please contact your superiors.");
			else {
				ResearcherPage page = new ResearcherPage();
				page.frame.setVisible(true);
				break;
			}
		}
		default:
			System.out.println("Invalid credentials!");
		}

	}

	public static String checkRole() throws Exception {
		return loginDAO.findRole(Main.username);
	}
}
