package main;

import java.util.*;

import javax.swing.table.DefaultTableModel;

import Model.*;

public class Table {

	public static void printEmployees(List<Employees> employeeList) {

		System.out.format("%-5s %-15s %-15s %-16s %-20s %s\n", "No.", "Name", "Age", "Address", "Contact",
				"Designation");
		Iterator<Employees> it = employeeList.iterator();
		int i = 1;
		while (it.hasNext()) {
			Employees e = it.next();
			System.out.printf("%-5s %-15s %-15s %-16s %-20s %s\n", i, e.getName(), e.getAge(), e.getAddress(),
					e.getContact(), e.getDesignation());
			i++;
		}
	}

	public static void printArtifacts(List<Artifacts> artifactsList) {

		System.out.format("%-15s %-25s %-16s %-20s %s\n", "File_Number", "Topic", "Published_Year", "Researcher_Name",
				"Disk_Location");
		Iterator<Artifacts> it = artifactsList.iterator();
		while (it.hasNext()) {
			Artifacts a = it.next();
			System.out.printf("%-15s %-25s %-16s %-20s %s\n", a.getFileNumber(), a.getTopic(), a.getPublishedYear(),
					a.getResearcherName(), a.getDiskLocation());
		}
	}

	public static DefaultTableModel printEmployeesGUI(List<Employees> employeeList) {

		String[] columnNames = { "No.", "Name", "Age", "Address", "Contact", "Designation" };

		Object[][] arr = new Object[employeeList.size()][6];

		for (int i = 0; i < employeeList.size(); i++) {
			Employees e = employeeList.get(i);
			arr[i][0] = i + 1;
			arr[i][1] = e.getName();
			arr[i][2] = e.getAge();
			arr[i][3] = e.getAddress();
			arr[i][4] = e.getContact();
			arr[i][5] = e.getDesignation();
		}
		DefaultTableModel model = new DefaultTableModel(arr, columnNames);
//		JTable table = new JTable(arr, columnNames);
		return model;
	}

	public static DefaultTableModel printArtifactsGUI(List<Artifacts> artifactsList) {

		String[] columnNames = {"File_Number", "Topic", "Published_Year", "Researcher_Name", "Disk_Location"};

		Object[][] arr = new Object[artifactsList.size()][5];

		for (int i = 0; i < artifactsList.size(); i++) {
			Artifacts a = artifactsList.get(i);
			arr[i][0] = a.getFileNumber();
			arr[i][1] = a.getTopic();
			arr[i][2] = a.getPublishedYear();
			arr[i][3] = a.getResearcherName();
			arr[i][4] = a.getDiskLocation();
		}
		DefaultTableModel model = new DefaultTableModel(arr, columnNames);
//		JTable table = new JTable(arr, columnNames);
		return model;
	}
	
	public static DefaultTableModel printSearchResearcherTable(Researchers researcher) {
		
		String[] columnNames = {"Name", "Manager"};

		Object[][] arr = new Object[1][2];
		
			arr[0][0] = researcher.getResearcherName();
			arr[0][1] = researcher.getManager();
		
		DefaultTableModel model = new DefaultTableModel(arr, columnNames);
//		JTable table = new JTable(arr, columnNames);
		return model;
	}

}
