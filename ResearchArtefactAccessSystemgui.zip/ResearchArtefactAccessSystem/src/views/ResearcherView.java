package views;

import java.util.List;
import DAO.*;
import GUI.*;
import Model.Artifacts;
import main.*;

public class ResearcherView extends View {
	
	public void display() throws Exception {
	}

	public void viewAllResearchArtifacts() throws Exception {
		ArtifactsDAO artifactsDAO = new ArtifactsDAO();
		List<Artifacts> artifactsList = artifactsDAO.fetchAllArtifactsWithResearcherName(Main.username);

		if (artifactsList.isEmpty())
			ResearcherPage.errorLabel.setText("You have no published research work items");
		else {
			ResearcherPage.frame.dispose();
			viewArtifacts(artifactsList);
		}

	}

	public void viewArtifacts(List<Artifacts> artifactList) {
		ViewArtifactsPage.artifactsList = artifactList;
		ViewArtifactsPage.model = Table.printArtifactsGUI(artifactList);
		ViewArtifactsPage artifactPage = new ViewArtifactsPage();
		artifactPage.frame.setVisible(true);
	}

	public String getArtifactsPath(List<Artifacts> artifactList, int num) {
		Artifacts artifact = artifactList.get(num);
		String path = artifact.getDiskLocation();
		return path;
	}

	public void uploadFile(String path, String topic) throws Exception {
		ArtifactsDAO artifactsDAO = new ArtifactsDAO();
		artifactsDAO.uploadFile(path,topic);
	}
	
	@Override
	public String viewArtifacts(List<Artifacts> artifactsList, int num) {
		// TODO Auto-generated method stub
		return null;
	}
}