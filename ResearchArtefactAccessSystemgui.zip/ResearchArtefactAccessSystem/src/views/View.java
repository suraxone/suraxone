package views;

import java.io.*;
import java.util.List;

import DAO.ArtifactsDAO;
import Model.*;
import main.*;

public abstract class View {

	public static final BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
	
	

	public View() {
	}

	public int optionTaker(int n) {
		while (true) {
			try {
				System.out.println("Enter your option");
				int input = Integer.parseInt(bf.readLine());
				if (input > 0 && input <= n) {
					return input;
				} else {
					System.out.println("invalid input");
				}
			} catch (NumberFormatException | IOException e) {
				System.out.println("invalid input! try again");
			}

		}
	}

	public int intTaker() {
		while (true) {
			try {
				System.out.print(">");
				int input = Integer.parseInt(bf.readLine());
				return input;
			} catch (NumberFormatException | IOException e) {
				System.out.println("invalid input! try again");
			}

		}
	}

	public String StringTaker() {
		while (true) {
			try {
				System.out.print(">");
				String input = bf.readLine();
				return input;
			} catch (NumberFormatException | IOException e) {
				System.out.println("invalid input! try again");
			}

		}
	}

	abstract void display() throws Exception;

	public void selection(List<Employees> employeeList) throws Exception {
		ArtifactsDAO artifactsDAO = new ArtifactsDAO();

//		Table.printEmployees(employeeList);
//		System.out.println();
//		System.out.println("Enter the serial number of the researcher you want to view the works :");
		int num = optionTaker(employeeList.size());

		Employees employee = employeeList.get(num - 1);

		List<Artifacts> artifactList = artifactsDAO.fetchAllArtifactsWithResearcherName(employee.getName());

		System.out.println();
		if (artifactList.isEmpty())
			System.out.println("There are no research work items for " + employee.getName());
		else
			Table.printArtifacts(artifactList);

		while (true) {
			System.out.println("1. Go to home page");
			System.out.println("2. Logout");

			switch (optionTaker(2)) {
			case 1: {
				display();
				break;
			}
			case 2: {
//				Main.main(null);
				break;
			}
			default:
				System.out.println("invalid option");
			}
		}
	}

	public void logout() throws Exception {
		System.out.println("Logged out successfully");
//		Main.main(null);
	}

	public abstract String viewArtifacts(List<Artifacts> artifactsList, int num);

	public abstract String getArtifactsPath(List<Artifacts> artifactsList, int num);

}
