package views;

import java.util.List;

import javax.swing.JOptionPane;

import DAO.*;
import GUI.ManagerPage;
import GUI.TeamLeadPage;
import GUI.ViewArtifactsPage;
import Model.*;
import main.*;

public class TeamLeadView extends View {

	ResearchersDAO researcherDAO = new ResearchersDAO();
	EmployeesDAO employeesDAO = new EmployeesDAO();
	ArtifactsDAO artifactsDAO = new ArtifactsDAO();

	public void display() throws Exception {

	}

	public void viewAllResearchers() throws Exception {
		List<Researchers> researcherslist = researcherDAO.fetchAllResearchersWithSameTeamLead(Main.username,
				employeesDAO.fetchAllTeamLeads());

		if (researcherslist.isEmpty())
			TeamLeadPage.errorLabel.setText("There are no researchers in your team");
		else {
			List<Employees> employeeList = employeesDAO.fetchEmployeeDetails(researcherslist);
			TeamLeadPage.model = Table.printEmployeesGUI(employeeList);
			TeamLeadPage.employeesList = employeeList;
		}
	}

	public void viewAllArtifacts() throws Exception {
		List<Researchers> researcherslist = researcherDAO.fetchAllResearchersWithSameTeamLead(Main.username,
				employeesDAO.fetchAllTeamLeads());
		List<Artifacts> artifactsList = artifactsDAO.fetchArtifactsDetails(researcherslist);
		if (artifactsList.isEmpty())
			TeamLeadPage.errorLabel.setText("There are no research work items published my your team members.");
		else {
			TeamLeadPage.frame.dispose();
			viewArtifacts(artifactsList);
		}

	}

	public void selection(List<Employees> employeeList, int num) throws Exception {
		ArtifactsDAO artifactsDAO = new ArtifactsDAO();
		Employees employee = employeeList.get(num);
		List<Artifacts> artifactList = artifactsDAO.fetchAllArtifactsWithResearcherName(employee.getName());

		if (artifactList.isEmpty())
			JOptionPane.showMessageDialog(null, "There are no research work items for " + employee.getName());
		else {
			TeamLeadPage.frame.dispose();
			viewArtifacts(artifactList);
		}
	}

	public void viewArtifacts(List<Artifacts> artifactList) {
		ViewArtifactsPage.artifactsList = artifactList;
		ViewArtifactsPage.model = Table.printArtifactsGUI(artifactList);
		ViewArtifactsPage artifactPage = new ViewArtifactsPage();
		artifactPage.frame.setVisible(true);
	}
	
	public String getArtifactsPath(List<Artifacts> artifactList, int num) {
		Artifacts artifact = artifactList.get(num);
		String path = artifact.getDiskLocation();
		return path;
	}

	@Override
	public String viewArtifacts(List<Artifacts> artifactsList, int num) {
		// TODO Auto-generated method stub
		return null;
	}
}
