package views;

import java.util.List;

import javax.swing.JOptionPane;

import DAO.*;
import GUI.*;
import Model.*;
import main.*;

public class ManagerView extends View{

	EmployeesDAO employeesDAO = new EmployeesDAO();
	ResearchersDAO researcherDAO = new ResearchersDAO();

	public void viewAllResearchers() throws Exception {
		List<Researchers> researcherslist = researcherDAO.fetchAllResearchersWithSameManager(Main.username);
		List<Employees> employeeList = employeesDAO.fetchEmployeeDetails(researcherslist);
		ManagerPage.employeesList = employeeList;

		if (employeeList.isEmpty())
			ManagerPage.errorLabel.setText("There are no researchers under you");
		else
			ManagerPage.model = Table.printEmployeesGUI(employeeList);
	}

	public void searchResearcher(String ResearcherName) throws Exception {

		if (researcherDAO.searchResearcher(ResearcherName)) {
			Researchers researcher = researcherDAO.fetchResearcher(ResearcherName);
			SearchResearcherPage.model = Table.printSearchResearcherTable(researcher);
			SearchResearcherPage.errorLabel.setText("");
		} else {
			SearchResearcherPage.errorLabel.setText(ResearcherName + " is not there in this company");
		}

	}

	public void selection(List<Employees> employeeList, int num) throws Exception {
		ArtifactsDAO artifactsDAO = new ArtifactsDAO();
		Employees employee = employeeList.get(num);
		List<Artifacts> artifactList = artifactsDAO.fetchAllArtifactsWithResearcherName(employee.getName());

		if (artifactList.isEmpty())
			JOptionPane.showMessageDialog(null, "There are no research work items for " + employee.getName());
		else {
			ManagerPage.frmManagerView.dispose();
			viewArtifacts(artifactList);
		}
	}

	public void viewArtifacts(List<Artifacts> artifactList) {
		ViewArtifactsPage.artifactsList = artifactList;
		ViewArtifactsPage.model = Table.printArtifactsGUI(artifactList);
		ViewArtifactsPage artifactPage = new ViewArtifactsPage();
		artifactPage.frame.setVisible(true);
	}

	public String getArtifactsPath(List<Artifacts> artifactList, int num) {
		Artifacts artifact = artifactList.get(num);
		String path = artifact.getDiskLocation();
		return path;
	}
	
	@Override
	void display() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String viewArtifacts(List<Artifacts> artifactsList, int num) {
		// TODO Auto-generated method stub
		return null;
	}
}
