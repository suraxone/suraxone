package Model;



public class Employees {

	private String name;
	private Integer age;
	private String address;
	private Long contact;
	private String Designation;

	
	public Employees() {
	}

	public Employees(String name, Integer age, String address, Long contact, String designation) {
		super();
		this.name = name;
		this.age = age;
		this.address = address;
		this.contact = contact;
		Designation = designation;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getContact() {
		return contact;
	}

	public void setContact(Long contact) {
		this.contact = contact;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	@Override
	public String toString() {
		return "Employees [name=" + name + ", age=" + age + ", address=" + address + ", contact=" + contact
				+ ", Designation=" + Designation + "]";
	}

	
	
	

}
