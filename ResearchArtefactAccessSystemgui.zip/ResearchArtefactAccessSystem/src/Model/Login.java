package Model;

public class Login {

	private String name;
	private String username;
	private String password;
	private String designation;

	public Login(String name, String username, String password, String designation) {
		super();
		this.name = name;
		this.username = username;
		this.password = password;
		this.designation = designation;
	}

	
	public Login() {
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	public String toString() {
		return "Login [name=" + name + ", username=" + username + ", password=" + password + ", designation="
				+ designation + "]";
	}

}
