package Model;

public class Artifacts {

	private Long fileNumber;
	private String topic;
	private Integer publishedYear;
	private String researcherName;
	private String diskLocation;

	public Artifacts(Long fileNumber, String topic, Integer publishedYear, String researcherName, String diskLocation) {
		super();
		this.fileNumber = fileNumber;
		this.topic = topic;
		this.publishedYear = publishedYear;
		this.researcherName = researcherName;
		this.diskLocation = diskLocation;
	}

	public Long getFileNumber() {
		return fileNumber;
	}

	public void setFileNumber(Long fileNumber) {
		this.fileNumber = fileNumber;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public Integer getPublishedYear() {
		return publishedYear;
	}

	public void setPublishedYear(Integer publishedYear) {
		this.publishedYear = publishedYear;
	}

	public String getResearcherName() {
		return researcherName;
	}

	public void setResearcherName(String researcherName) {
		this.researcherName = researcherName;
	}

	public String getDiskLocation() {
		return diskLocation;
	}

	public void setDiskLocation(String diskLocation) {
		this.diskLocation = diskLocation;
	}

	@Override
	public String toString() {
		return "Artifacts [fileNumber=" + fileNumber + ", topic=" + topic + ", publishedYear=" + publishedYear
				+ ", researcherName=" + researcherName + ", diskLocation=" + diskLocation + "]";
	}

}
