package Model;

public class Researchers {

	private String researcherName;
	private String manager;
	private String teamlead;
	private boolean AdvisorApproved;

	public Researchers(String researcherName, String manager, String teamlead, boolean advisorApproved) {
		super();
		this.researcherName = researcherName;
		this.manager = manager;
		this.teamlead = teamlead;
		AdvisorApproved = advisorApproved;
	}

	
	public Researchers() {
	}


	public String getResearcherName() {
		return researcherName;
	}

	public void setResearcherName(String researcherName) {
		this.researcherName = researcherName;
	}

	public String getManager() {
		return manager;
	}

	public void setManager(String manager) {
		this.manager = manager;
	}

	public String getTeamlead() {
		return teamlead;
	}

	public void setTeamlead(String teamlead) {
		this.teamlead = teamlead;
	}

	public boolean isAdvisorApproved() {
		return AdvisorApproved;
	}

	public void setAdvisorApproved(boolean advisorApproved) {
		AdvisorApproved = advisorApproved;
	}

	@Override
	public String toString() {
		return "Researchers [researcherName=" + researcherName + ", manager=" + manager + ", teamlead=" + teamlead
				+ ", AdvisorApproved=" + AdvisorApproved + "]";
	}

}
